const UserAuth = (name,email,password,res)=>{
    if(!name || !email || !password){
        
    }
}