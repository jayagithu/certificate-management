const UserAuth = (name,email,password)=>{
    if(!name || !email || !password){
        res
    }
}