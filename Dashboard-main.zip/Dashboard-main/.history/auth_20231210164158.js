const UserAuth = (name,email,password,res,next)=>{
    if(!name || !email || !password){
        res.re
    }
}