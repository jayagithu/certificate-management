const UserAuth = (name,email,password)=>{
    if(!name || !emai)
}